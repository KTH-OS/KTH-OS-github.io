void *balloc(size_t size);

void bree(void *memory);

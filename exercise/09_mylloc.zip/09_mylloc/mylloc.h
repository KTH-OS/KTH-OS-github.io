
void *mylloc(size_t size);
void mhysa(void *ptr);


// gcc -o mlfq mlfq.c -lm
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

typedef struct job {
	int id;               // unique id
	int arrival;          // when job arrives (or after blocking, when it should be unblocked)
	int exectime;         // expected execution time left 
	int totaltime;        // in the end, the total execution time (will be used during the simulation)
	float ioratio;        // ratio for I/O operation during a scheduled time slot 
	int unblocked;        // if the job was recently unblocked 
	int blockedn;         // number of times being unblocked
	int blockedt;         // accumulated time from being unblocked to being scheduled
	struct job *next;
} job;

typedef struct spec {
	int arrival;
	int exectime;
	float ioratio;
} spec;

#define SLOT 10
#define IO 30 

spec specs[] = {
	{0, 10, 0.0},
	{0, 30, 0.7},
	{0, 20, 0.0},
	{40, 80, 0.4},
	{60, 30, 0.3},  
	{120, 90, 0.3},  
	{120, 40, 0.5},
	{140, 20, 0.2},
	{160, 10, 0.3},
	{180, 20, 0.3},
	{0, 0, 0}
};

job *readyq = NULL;
job *blockedq = NULL;
job *doneq = NULL;

void status() {
	job *blkd = blockedq;
	printf("blocked : ");
	while (blkd != NULL) {
		printf("(%d, %d) ", blkd->id, blkd->arrival);
		blkd = blkd->next;
	}

	printf("\n");
	job *red = readyq;
  	printf("ready : ");
	while (red != NULL) {
		printf("(%d, %d) ", red->id, red->exectime);
		red = red->next;
	}

	printf("\n");
	job *done = doneq;
	printf("done : ");
	while (done != NULL) {
		printf("(%d, %d) ", done->id, done->exectime);
		done = done->next;
	}

	printf("\n");    
}


/* round robin, add it as last job in queue */
void ready(job *this) {
	job *nxt = readyq;
	job *prev = NULL;
	while (nxt != NULL && nxt->exectime <= this->exectime) { // 
		prev = nxt;
		nxt = nxt->next;
	}

	this->next = nxt;
	if (prev == NULL) {
		readyq = this;
	} else {
		prev->next = this;
	}

	return;
}

/* add to list of done jobs */
void done(job *this) {
	this->next = doneq;
	doneq = this;
	return;
}

/* add to blocked queue, order on arrival  */ 
void block(job *this) {
	job *nxt = blockedq;
	job *prev = NULL;

	this->blockedn = this->blockedn + 1;
	while (nxt != NULL) {
		if (this->arrival < nxt->arrival) {
			break;
		} else {
			prev = nxt;
			nxt = nxt->next;
		}
	}

	this->next = nxt;
	if (prev != NULL) {
		prev->next = this;
	} else {
		blockedq = this;
	}

	return;
}

/* given current time, move jobs from blocked to ready */
void unblock(int time) {
	while (blockedq != NULL && blockedq->arrival <= time) {
		job *nxt = blockedq;
		blockedq = nxt->next; 
		ready(nxt);
	}
}

/* initialize the blocked queue from specification */
void init() {
	int i = 0;
	while (specs[i].exectime != 0) {
		job *new = (job *)malloc(sizeof(job));
		new->id = i+1;
		new->arrival = specs[i].arrival;
		new->exectime = specs[i].exectime;
		new->totaltime = specs[i].arrival;  // we set it to arrival to remember
		new->ioratio = specs[i].ioratio;
		new->unblocked = 0;
		new->blockedn = 0;
		new->blockedt = 0;
		block(new);
		i++;
	}
}

int schedule(int time) {
	if (readyq != NULL) {
		job *nxt = readyq;
		readyq = readyq->next;

		// printf("time %d scheduling job %d\n", time, nxt->id);
		printf("%d-(%d) ", nxt->id, nxt->exectime);
		if (nxt->exectime <= SLOT) {
			// This is it
			int passed = nxt->exectime;
			nxt->totaltime = time + passed - nxt->totaltime;
			nxt->exectime = 0;
			done(nxt);
			return passed;
		} else {
			if (((float)rand()) / RAND_MAX < nxt->ioratio) {
				int x = (int)ceilf(((float)rand() / RAND_MAX) * SLOT);
				printf("\ntime %d i/o operation job %d after %d ms\n", time, nxt->id, x);
				nxt->exectime = nxt->exectime - SLOT;
				ready(nxt);
				return SLOT + IO;
			} else {
				nxt->exectime = nxt->exectime - SLOT;
				ready(nxt);
				return SLOT;
			}
		}
	} else {
		return 1;
	}
}

int main() {
	init();
	int time = 0;

	while (blockedq != NULL || readyq != NULL) {
		unblock(time);
		int tick = schedule(time);
		time = time + tick;
	}

	int turnaround = 0;
	int jobs = 0;
	job *done = doneq;
  
	printf("\ndone : ");
	while (done != NULL) {
		jobs += 1;
		turnaround += done->totaltime;
		printf("(%d, %d) ", done->id, done->totaltime);
		done = done->next;
	}

	printf("\n");      
	printf("\naverage turnaround time is %.2f \n", ((double)turnaround)/jobs);  
	printf("\ntime is %d \n", time);
	
	return 0;
}


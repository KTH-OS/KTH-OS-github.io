#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* function to be run as a thread always must have the same signature:
   it has one void* parameter and returns void */
void *threadfunction(void *arg) {
	printf("%s\n", (char *)arg); 
	return 0;
}

int main() {
	pthread_t thread;
	char *msg = "Hello world!";
  
	int createerror = pthread_create(&thread, NULL, threadfunction, msg);
  
	/*creates a new thread with default attributes and msg passed as the argument to the start routine*/
	if (!createerror) { /*check whether the thread creation was successful*/
		pthread_join(thread, NULL); /*wait until the created thread terminates*/
		exit(EXIT_SUCCESS);
	}
  
	perror("pthread create");
	exit(EXIT_FAILURE);
}


#include <stdio.h>
#include <unistd.h>

int main() {
	printf("Don't get in my way.");
	return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/wait.h>

const char *sem_name = "semi";

void parent() {
    sem_t *sem_id = sem_open(sem_name, O_CREAT, 0600, 0);

    printf("Parent: Wait for Child to Print.\n");
    sem_wait(sem_id);
    printf("Parent: Child Printed!\n");
    sem_close(sem_id);
    sem_unlink(sem_name);
}

void child() {
    sem_t *sem_id = sem_open(sem_name, O_CREAT, 0600, 0);
    printf("Child: Hello parent!\n");
    sem_post(sem_id);
}

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        child();
    } else {
        int status;
        parent();
        wait(&status);
    }

    return 0;
}

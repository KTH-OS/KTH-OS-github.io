#include<stdio.h>

int main() {
    FILE *fd = fopen("myfile.txt", "r");
    int ch = getc(fd);

    while (ch != EOF) {
	printf("%c", ch);
	ch = getc(fd);
    }

    fclose(fd);
    return 0;
}
#include <stdio.h>

int main (void) {
    FILE *fd;

    fd = fopen("myfile.txt", "w");

    fputs("This is a sample text file.\n", fd);
    fputs("This file contains some sample text data.", fd);

    fclose(fd);
    return 0;
}
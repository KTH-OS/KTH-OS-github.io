#include <stdio.h>

int main (void) {
    FILE *fd;

    fd = fopen("myfile.txt", "w");

    fprintf(fd, "%s %s %d.\n", "This", "is",  5);

    fclose(fd);
    return 0;
}
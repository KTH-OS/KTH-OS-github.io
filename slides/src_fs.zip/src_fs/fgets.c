#include <stdio.h>

int main(void) {
    FILE* fd;
    char ch[100];

    fd = fopen("myfile.txt", "r");

    printf("%s", fgets(ch, 50, fd));

    fclose(fd);
    return 0;
}
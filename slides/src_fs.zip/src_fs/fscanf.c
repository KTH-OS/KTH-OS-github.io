#include <stdio.h>

int main() {
    char str1[10], str2[10];
    int n;
    FILE* fd;

    fd = fopen("anything.txt", "w+");

    fputs("This is 5", fd);

    rewind(fd);

    fscanf(fd, "%s %s %d", str1, str2, &n);

    printf("1st word %s\n", str1);
    printf("2nd word  %s\n", str2);
    printf("3rd word  %d\n", n);

    fclose(fd);
    return 0;
}

#include <stdio.h>
#include <string.h>

int main (void) {
    FILE *fd;
    int i;
    char *string = "This is an example.";
    
    fd = fopen("myfile.txt", "wt");
    
    for (i = 0; i < strlen(string); i++) {
        putc(string[i], fd);
    }

    fclose (fd);
    return 0;
}

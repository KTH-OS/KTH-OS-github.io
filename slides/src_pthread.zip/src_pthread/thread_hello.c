#include <pthread.h>
#include <stdio.h>
#include <string.h>

void *thread_func(void *arg) {
  printf("Hello, World!\n");
  return 0;
}

int main() {
  pthread_t thread;

  pthread_create(&thread, NULL, thread_func, NULL);
  
  pthread_join(thread, NULL);
  return 0;
}

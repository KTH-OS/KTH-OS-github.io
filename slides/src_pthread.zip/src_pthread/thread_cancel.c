#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>

int counter = 0; 
  
pthread_t tmp_thread; 
  
void* thread_func1(void* args) {
  while (1) {
    printf("thread number one\n");
    sleep(1);
    counter++;   
        
    if (counter == 2) {
      pthread_cancel(tmp_thread); 
      pthread_exit(NULL);  
    }
  }
}
  
void* thread_func2(void* args) {
  tmp_thread = pthread_self(); 
  
  while (1) {
    printf("thread number two\n");
    sleep(1); // sleep 1 second
  }
}
  
int main() {
  pthread_t thread1, thread2; 
  
  pthread_create(&thread1, NULL, thread_func1, NULL);
  pthread_create(&thread2, NULL, thread_func2, NULL); 
  
  pthread_join(thread1, NULL); 
  pthread_join(thread2, NULL); 
}

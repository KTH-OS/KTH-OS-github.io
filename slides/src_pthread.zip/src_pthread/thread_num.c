#include <stdio.h>
#include <pthread.h>

void *thread_func(void *arg) {
  printf("I'm thread #%d\n", *(int *)arg);
  return NULL;
}

int main() {
  pthread_t thread1, thread2;
  int i = 1;
  int j = 2;

  pthread_create(&thread1, NULL, &thread_func, &i);
  pthread_create(&thread2, NULL, &thread_func, &j);

  pthread_join(thread1, NULL);
  pthread_join(thread2, NULL);

  printf("I'm the main thread\n");
  return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

struct thread_args {
  int a;
  double b;
};


struct thread_result {
  long x;
  double y;
};

void *thread_func(void *args_void) {
    struct thread_args *args = args_void;
    struct thread_result *res = malloc(sizeof *res);

    res->x = args->a * 2;
    res->y = args->b * 2;
    
    return res;
}

int main() {
    pthread_t thread;
    struct thread_args in = { .a = 10, .b = 3.14 };
    void *out_void;
    struct thread_result *out;

    pthread_create(&thread, NULL, thread_func, &in);
    pthread_join(thread, &out_void);
    out = out_void;
    
    printf("out.x = %ld\nout.y = %f\n", out->x, out->y);
    free(out);

    return 0;
}
